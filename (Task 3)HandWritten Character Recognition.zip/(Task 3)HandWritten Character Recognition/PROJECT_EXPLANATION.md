# Handwritten Character Recognition - Complete Detailed Explanation

This document explains the project end-to-end: what it does, how each file works, how data flows through the system, how training and prediction work, how to run the project, and how to extend it.

---

## 1) Project Goal

The goal is to recognize handwritten characters using deep learning.

Planned recognition scope:
- Digits: `0-9`
- Letters: `A-Z`

Current runtime behavior:
- The code first tries to use **MNIST + EMNIST Letters** (36 classes total).
- If EMNIST is unavailable due to network/mirror issues, it falls back to **MNIST only** (10 classes).

So the project is robust: it still runs and demonstrates the complete ML pipeline even when the letter dataset source is blocked.

---

## 2) High-Level Architecture

The project has 3 major layers:

1. **Data + Training Layer**
   - Loads dataset(s), preprocesses data, trains CNN, evaluates accuracy, saves model artifacts.

2. **Inference Layer**
   - Takes input image (drawn or uploaded), preprocesses to model format, predicts class probabilities.

3. **Frontend Demo Layer**
   - Streamlit app where user draws/uploads character and sees prediction with confidence.

Flow:
1. `train.py` trains model and saves files in `artifacts/`.
2. `app.py` loads saved model + class map.
3. User inputs an image.
4. `src/preprocess.py` transforms image to 28x28 normalized tensor.
5. Model predicts probabilities.
6. App shows top prediction + top-5 scores.

---

## 3) File-by-File Explanation

### `requirements.txt`
Lists Python dependencies:
- `tensorflow` - model creation/training/inference
- `numpy` - array operations
- `opencv-python` - image thresholding, contours, resizing
- `Pillow` - image handling
- `scikit-learn` - train/validation split
- `extra-keras-datasets` - EMNIST dataset source
- `streamlit` - web UI
- `streamlit-drawable-canvas` - drawing canvas component
- `matplotlib` - plotting support (future extension)

---

### `src/dataset.py`
Handles dataset loading and preparation.

Main components:
- `DatasetBundle` dataclass: container for `x_train`, `y_train`, `x_test`, `y_test`, `class_map`.
- `_normalize_images()`: converts pixel values from `[0..255]` to `[0..1]` and adds channel dimension.
- `_mnist_to_uppercase_map()`: creates label map for 36 classes.
  - `0..9 -> "0".."9"`
  - `10..35 -> "A".."Z"`
- `_prepare_emnist_letters()`: fixes EMNIST labels and orientation:
  - adjusts labels to align with 10-35 range
  - rotates/flips image axes to match MNIST orientation
- `load_digits_and_letters_dataset()`:
  - loads MNIST
  - tries EMNIST letters
  - if EMNIST succeeds: merges MNIST + EMNIST
  - if EMNIST fails: falls back to MNIST only
  - returns normalized arrays + class mapping

Why fallback exists:
- EMNIST mirror endpoints can return errors (`403`, corrupt zip from unstable mirror).
- Fallback ensures demo/project remains runnable.

---

### `src/model.py`
Defines the CNN architecture.

`build_cnn_model(num_classes)` creates:
- Input: `(28, 28, 1)`
- Conv block 1:
  - Conv2D(32) + BatchNorm
  - Conv2D(32)
  - MaxPooling
  - Dropout(0.25)
- Conv block 2:
  - Conv2D(64) + BatchNorm
  - Conv2D(64)
  - MaxPooling
  - Dropout(0.25)
- Classifier:
  - Flatten
  - Dense(256, relu)
  - Dropout(0.4)
  - Dense(`num_classes`, softmax)

Compile settings:
- Optimizer: `adam`
- Loss: `sparse_categorical_crossentropy`
- Metric: `accuracy`

Why this model:
- Strong baseline for small grayscale character images
- Good capacity while remaining lightweight enough for demo use

---

### `src/preprocess.py`
Transforms raw user image to model-ready input.

`preprocess_for_inference(pil_image)` steps:
1. Convert to grayscale.
2. Invert colors so handwriting is bright foreground (MNIST-like).
3. Binary threshold to isolate strokes.
4. Find largest contour (main character).
5. Crop ROI around the character.
6. Pad to square canvas to preserve aspect ratio.
7. Resize to 20x20 and center in 28x28 frame (MNIST-style framing).
8. Normalize to `[0..1]`.
9. Reshape to `(1, 28, 28, 1)` for model input.

This is crucial because model performance depends heavily on consistent input style.

---

### `train.py`
Main training script.

What it does:
1. Parses CLI args:
   - `--epochs`
   - `--batch-size`
   - `--model-out`
   - `--labels-out`
2. Loads dataset from `src/dataset.py`.
3. Builds CNN from `src/model.py`.
4. Splits train into train/validation (`train_test_split`, stratified).
5. Trains with callbacks:
   - `EarlyStopping` (restore best model)
   - `ReduceLROnPlateau`
6. Evaluates on test set.
7. Saves:
   - Keras model (`.keras`)
   - class mapping JSON

Output artifacts default paths:
- `artifacts/handwritten_cnn.keras`
- `artifacts/class_map.json`

---

### `app.py`
Streamlit frontend and inference orchestration.

Main features:
- Loads model and class map with Streamlit caching.
- Tabs:
  - **Draw**: freehand canvas input
  - **Upload**: image file input
  - **Project Info**: objective, approach, current mode
- Prediction display:
  - best class + confidence
  - top-5 predictions via progress bars

Important behavior:
- It checks whether model artifacts exist.
  - If not, it instructs user to run training first.
- It displays mode dynamically:
  - 36-class mode if letters available during training
  - 10-class (digits-only) fallback otherwise

---

### `README.md`
Quick-start guide:
- setup
- install dependencies
- train
- run app

This new document (`PROJECT_EXPLANATION.md`) is the deep-dive companion to README.

---

### `src/__init__.py`
Marks `src` as a Python package so module imports are clean and predictable.

---

## 4) Training Details

### Input format
- Image size: `28x28`
- Channels: `1` (grayscale)
- Pixel scale: `[0..1]`

### Labels
- Digits mode: 10 labels (`0..9`)
- Full mode: 36 labels (`0..9`, `A..Z`)

### Why `sparse_categorical_crossentropy`
Labels are integer encoded (not one-hot vectors), so sparse loss is appropriate.

### Callbacks
- Early stopping prevents overfitting and unnecessary epochs.
- ReduceLROnPlateau lowers learning rate when progress slows.

---

## 5) Inference Details (What happens during a prediction)

1. User draws or uploads image.
2. Image is converted to model-friendly format by `preprocess_for_inference`.
3. Model outputs a probability vector:
   - length 10 or 36 depending on trained mode.
4. Highest probability index selected as predicted class.
5. Index mapped to character through `class_map.json`.
6. UI shows final class and confidence bars.

---

## 6) Artifacts and Their Purpose

### `artifacts/handwritten_cnn.keras`
Serialized trained model containing:
- architecture
- learned weights
- optimizer state (where applicable)

### `artifacts/class_map.json`
Dictionary of model output index to character label.

Examples:
- Digits-only:
  - `"0": "0"`, ..., `"9": "9"`
- Full:
  - `"10": "A"`, ..., `"35": "Z"`

---

## 7) How to Run (Recommended Commands)

From project root:

```powershell
py -3.11 -m venv .venv311
.venv311\Scripts\Activate.ps1
pip install -r requirements.txt
python train.py --epochs 12 --batch-size 128
streamlit run app.py --server.port 8501
```

Then open:
- `http://localhost:8501`

---

## 8) Known Issues + Practical Notes

1. **EMNIST download reliability**
   - Some EMNIST sources may fail with HTTP errors.
   - Project automatically falls back to MNIST-only mode.

2. **Prediction quality depends on preprocessing**
   - centered, single character input works best
   - thick clear strokes improve confidence

3. **Digits-only mode is still valid demo**
   - all ML components remain the same
   - only class set is reduced from 36 to 10

---

## 9) Extension Roadmap

If you want to push this to the next level:

1. Reliable letter dataset mirror management with checksum validation.
2. Data augmentation (rotation, shift, elastic distortion).
3. Confusion matrix + per-class accuracy report.
4. Training history charts in app.
5. Export to ONNX/TFLite for lightweight deployment.
6. Word-level recognition:
   - segment characters + CNN, or
   - CRNN/CTC for sequence recognition.

---

## 10) What Makes This Project "Complete"

This implementation includes:
- data ingestion
- preprocessing
- model design
- training
- evaluation
- artifact persistence
- interactive frontend demo
- fallback handling for dataset failures
- documentation for setup and explanation

So it is both:
- **presentable** for project demonstration
- **practical** for local execution on your machine

