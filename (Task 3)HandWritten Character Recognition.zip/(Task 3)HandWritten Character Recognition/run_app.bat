@echo off
setlocal
cd /d "%~dp0"

if exist ".venv311\Scripts\python.exe" (
    set "PY=.venv311\Scripts\python.exe"
) else if exist ".venv\Scripts\python.exe" (
    set "PY=.venv\Scripts\python.exe"
) else (
    echo No virtualenv found. Create .venv311 with Python 3.11 and run:
    echo   py -3.11 -m venv .venv311
    echo   .venv311\Scripts\python.exe -m pip install -r requirements.txt
    exit /b 1
)

echo Using: %PY%
"%PY%" -m streamlit run app.py
