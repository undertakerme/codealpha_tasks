$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
Set-Location $Root

$Py311 = Join-Path $Root ".venv311\Scripts\python.exe"
$PyDefault = Join-Path $Root ".venv\Scripts\python.exe"

$Py = $null
if (Test-Path $Py311) { $Py = $Py311 }
elseif (Test-Path $PyDefault) { $Py = $PyDefault }

if (-not $Py) {
    Write-Host "No virtualenv found. Create one with Python 3.11, then:"
    Write-Host "  cd `"$Root`""
    Write-Host "  py -3.11 -m venv .venv311"
    Write-Host "  .\.venv311\Scripts\python.exe -m pip install -r requirements.txt"
    exit 1
}

Write-Host "Using: $Py"
& $Py -m streamlit run app.py
