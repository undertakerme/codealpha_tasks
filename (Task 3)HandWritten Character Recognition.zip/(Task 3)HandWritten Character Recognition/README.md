# Handwritten Character Recognition (Task 3)

Complete project implementation for handwritten character/alphabet recognition using a CNN, with a modern Streamlit frontend for live demo.

## Features

- Recognizes **digits (0-9)** and **uppercase letters (A-Z)**.
- Uses **MNIST + EMNIST letters** datasets.
- Includes robust image preprocessing for real-world drawn/uploaded images.
- Interactive frontend:
  - Draw character on canvas and predict
  - Upload image and predict
  - Top-5 confidence display

## Tech Stack

- Python
- TensorFlow / Keras (CNN model)
- OpenCV + Pillow (image preprocessing)
- Streamlit + drawable canvas (frontend UI)

## Project Structure

```text
.
|-- app.py
|-- train.py
|-- requirements.txt
|-- artifacts/                 # generated after training
|   |-- handwritten_cnn.keras
|   `-- class_map.json
`-- src/
    |-- dataset.py
    |-- model.py
    `-- preprocess.py
```

## Setup

1. Create virtual environment (recommended):

```bash
python -m venv .venv
```

2. Activate environment:

```bash
# Windows PowerShell
.venv\Scripts\Activate.ps1
```

3. Install dependencies:

```bash
pip install -r requirements.txt
```

## Train the Model

```bash
python train.py --epochs 12 --batch-size 128
```

Artifacts are saved in `artifacts/`.

## Run Frontend Demo

```bash
streamlit run app.py
```

Open the displayed local URL in your browser.

## Notes

- First training run may take time due to dataset download.
- EMNIST letters are mapped to uppercase labels A-Z.
- For best prediction quality, draw one centered character at a time.

