from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import streamlit as st
from PIL import Image
from streamlit_drawable_canvas import st_canvas
from tensorflow.keras.models import load_model

from src.preprocess import inference_input_batch

ARTIFACTS_DIR = Path("artifacts")
MODEL_PATH = ARTIFACTS_DIR / "handwritten_cnn.keras"
LABELS_PATH = ARTIFACTS_DIR / "class_map.json"


@st.cache_resource
def get_model():
    return load_model(MODEL_PATH)


@st.cache_data
def get_class_map() -> Dict[int, str]:
    with LABELS_PATH.open("r", encoding="utf-8") as fp:
        raw = json.load(fp)
    return {int(k): v for k, v in raw.items()}


def top_predictions(pred: np.ndarray, class_map: Dict[int, str], k: int = 5) -> List[Tuple[str, float]]:
    indices = np.argsort(pred[0])[::-1][:k]
    return [(class_map[int(i)], float(pred[0][i])) for i in indices]


def run_prediction(image: Image.Image, model, class_map: Dict[int, str], *, source: str = "draw") -> None:
    batch = inference_input_batch(image, source=source)
    pred = model.predict(batch, verbose=0)
    if pred.shape[0] > 1:
        pred = pred.mean(axis=0, keepdims=True)
    best_idx = int(np.argmax(pred[0]))
    confidence = float(pred[0][best_idx])
    st.success(f"Prediction: **{class_map[best_idx]}** ({confidence * 100:.2f}% confidence)")
    st.write("Top-5 predictions:")
    for label, score in top_predictions(pred, class_map):
        st.progress(score, text=f"{label}: {score * 100:.2f}%")


def main() -> None:
    st.set_page_config(
        page_title="Handwritten Character Recognition",
        page_icon="✍️",
        layout="wide",
    )
    st.title("✍️ Handwritten Character Recognition Demo")

    if not MODEL_PATH.exists() or not LABELS_PATH.exists():
        st.warning("Model artifacts not found.")
        st.code("python train.py --epochs 12 --batch-size 128", language="bash")
        st.stop()

    model = get_model()
    class_map = get_class_map()
    if len(class_map) == 36:
        st.caption("CNN-based recognizer for digits (0-9) and uppercase letters (A-Z).")
    else:
        st.caption("CNN-based recognizer currently running in digits-only mode (0-9).")

    tab_draw, tab_upload, tab_info = st.tabs(["Draw", "Upload", "Project Info"])

    with tab_draw:
        st.subheader("Draw a Character")
        col1, col2 = st.columns([1.2, 1], gap="large")
        with col1:
            canvas_result = st_canvas(
                fill_color="rgba(255, 255, 255, 0)",
                stroke_width=14,
                stroke_color="#ffffff",
                background_color="#000000",
                height=320,
                width=320,
                drawing_mode="freedraw",
                key="canvas",
            )
        with col2:
            st.write("Tips")
            st.markdown(
                "- Draw one character only\n"
                "- Use thick centered strokes\n"
                "- Keep character centered in canvas"
            )
            if st.button("Predict Drawn Character", use_container_width=True):
                if canvas_result.image_data is None:
                    st.error("Please draw a character first.")
                else:
                    rgba = np.uint8(canvas_result.image_data)
                    image = Image.fromarray(rgba).convert("RGB")
                    run_prediction(image, model, class_map, source="draw")

    with tab_upload:
        st.subheader("Upload an Image")
        st.caption(
            "Uploaded images use extra smoothing + multiple views for prediction. Results are "
            "best when the glyph looks like handwritten print; ornate fonts or heavy textures "
            "still differ from the training data (EMNIST + MNIST)."
        )
        uploaded_file = st.file_uploader("Choose image", type=["png", "jpg", "jpeg", "bmp"])
        if uploaded_file:
            image = Image.open(uploaded_file)
            st.image(image, caption="Uploaded Image", width=220)
            if st.button("Predict Uploaded Image", use_container_width=True):
                run_prediction(image, model, class_map, source="upload")

    with tab_info:
        st.subheader("About This Project")
        mode = "36 classes (0-9 and A-Z)" if len(class_map) == 36 else "10 classes (0-9)"
        dataset = "MNIST + EMNIST Letters" if len(class_map) == 36 else "MNIST (fallback mode)"
        st.markdown(
            f"""
            - **Objective:** identify handwritten digits and alphabets.
            - **Approach:** image preprocessing + Convolutional Neural Network (CNN).
            - **Dataset:** {dataset}.
            - **Model classes:** {mode}.
            - **Extensible:** can be upgraded to sequence models for word-level recognition.
            """
        )


if __name__ == "__main__":
    main()
