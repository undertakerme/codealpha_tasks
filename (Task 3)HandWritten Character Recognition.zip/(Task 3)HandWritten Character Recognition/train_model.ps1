$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
Set-Location $Root

$Py311 = Join-Path $Root ".venv311\Scripts\python.exe"
$PyDefault = Join-Path $Root ".venv\Scripts\python.exe"

$Py = $null
if (Test-Path $Py311) { $Py = $Py311 }
elseif (Test-Path $PyDefault) { $Py = $PyDefault }

if (-not $Py) {
    Write-Host "No virtualenv found. Install Python 3.11 and create .venv311 (see README / run_app.ps1 hints)."
    exit 1
}

& $Py train.py --epochs 12 --batch-size 128
