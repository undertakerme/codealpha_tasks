from __future__ import annotations

from typing import List

import cv2
import numpy as np
from PIL import Image


def _center_by_mass(image: np.ndarray) -> np.ndarray:
    """Shift foreground so its center-of-mass sits at the canvas center."""
    coords = np.column_stack(np.where(image > 0))
    if coords.size == 0:
        return image

    cy, cx = coords.mean(axis=0)
    target = (image.shape[0] - 1) / 2.0
    shift_y = int(round(target - cy))
    shift_x = int(round(target - cx))

    matrix = np.float32([[1, 0, shift_x], [0, 1, shift_y]])
    return cv2.warpAffine(image, matrix, (image.shape[1], image.shape[0]), borderValue=0)


def _extract_foreground(gray: np.ndarray) -> np.ndarray:
    """Auto-detect stroke polarity (dark-on-light vs light-on-dark)."""
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    _, dark_fg = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    _, light_fg = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    dark_pixels = int(np.count_nonzero(dark_fg))
    light_pixels = int(np.count_nonzero(light_fg))
    foreground = dark_fg if dark_pixels <= light_pixels else light_fg

    if np.count_nonzero(foreground) < 5:
        return np.zeros_like(gray, dtype=np.uint8)
    return foreground


def _lab_luminance(pil_image: Image.Image) -> np.ndarray:
    """L channel separates lightness from chroma — better for textured / colored glyphs."""
    rgb = np.array(pil_image.convert("RGB"), dtype=np.uint8)
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
    return lab[:, :, 0]


def _maybe_downscale_gray(gray: np.ndarray, max_side: int = 768) -> np.ndarray:
    h, w = gray.shape[:2]
    side = max(h, w)
    if side <= max_side:
        return gray
    scale = max_side / side
    new_w = max(1, int(round(w * scale)))
    new_h = max(1, int(round(h * scale)))
    return cv2.resize(gray, (new_w, new_h), interpolation=cv2.INTER_AREA)


def _foreground_from_smoothed_gray(gray_smooth: np.ndarray, close_kernel: int) -> np.ndarray:
    """Binarize + morphology; close_kernel fills texture-induced gaps inside strokes."""
    thresh = _extract_foreground(gray_smooth)
    k = max(3, close_kernel | 1)  # odd kernel size
    kernel = np.ones((k, k), np.uint8)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=1)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8), iterations=1)
    return thresh


def _components_mask(thresh: np.ndarray) -> np.ndarray:
    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(thresh, connectivity=8)
    min_area = max(20, int(0.001 * thresh.shape[0] * thresh.shape[1]))
    mask = np.zeros_like(thresh, dtype=np.uint8)
    for label_idx in range(1, n_labels):
        area = stats[label_idx, cv2.CC_STAT_AREA]
        if area >= min_area:
            mask[labels == label_idx] = 255

    if np.count_nonzero(mask) == 0:
        mask = thresh
    return mask


def _binary_mask_to_tensor(mask: np.ndarray) -> np.ndarray:
    mask = _components_mask(mask)

    if np.count_nonzero(mask) == 0:
        return np.zeros((1, 28, 28, 1), dtype=np.float32)

    ys, xs = np.where(mask > 0)
    y_min = max(int(ys.min()) - 2, 0)
    y_max = min(int(ys.max()) + 3, mask.shape[0])
    x_min = max(int(xs.min()) - 2, 0)
    x_max = min(int(xs.max()) + 3, mask.shape[1])
    roi = mask[y_min:y_max, x_min:x_max]

    h, w = roi.shape[:2]
    scale = 20.0 / max(h, w)
    new_h = max(1, int(round(h * scale)))
    new_w = max(1, int(round(w * scale)))
    resized = cv2.resize(roi, (new_w, new_h), interpolation=cv2.INTER_AREA)

    canvas = np.zeros((28, 28), dtype=np.uint8)
    y_off = (28 - new_h) // 2
    x_off = (28 - new_w) // 2
    canvas[y_off : y_off + new_h, x_off : x_off + new_w] = resized
    canvas = _center_by_mass(canvas)

    normalized = canvas.astype("float32") / 255.0
    return normalized.reshape(1, 28, 28, 1)


def _upload_preprocessing_gray_variants(lum: np.ndarray) -> List[np.ndarray]:
    """
    Produce several smoothed grayscale views — textured fills (wood grain etc.) confuse a
    single Otsu threshold; smoothing + morphology + ensembling softmax helps.
    """
    variants: List[np.ndarray] = [
        cv2.bilateralFilter(lum, 9, 90, 90),
        cv2.GaussianBlur(lum, (11, 11), 0),
        cv2.medianBlur(lum, 7),
        cv2.bilateralFilter(cv2.equalizeHist(lum), 7, 60, 60),
    ]
    return variants


def inference_input_batch(pil_image: Image.Image, *, source: str = "draw") -> np.ndarray:
    """
    Return a batch tensor (n, 28, 28, 1). Draw uses n=1; upload uses multiple variants for ensembling.

    Args:
        pil_image: RGB or grayscale image from canvas or upload.
        source: "draw" uses simple luminance pipeline; "upload" uses LAB + texture-robust variants.
    """
    if source != "upload":
        gray = np.array(pil_image.convert("L"))
        thresh = _foreground_from_smoothed_gray(cv2.GaussianBlur(gray, (5, 5), 0), close_kernel=3)
        row = _binary_mask_to_tensor(thresh)
        return row

    lum = _lab_luminance(pil_image)
    lum = _maybe_downscale_gray(lum)

    tensors: List[np.ndarray] = []
    close_sizes = [5, 7, 5, 5]
    for idx, gv in enumerate(_upload_preprocessing_gray_variants(lum)):
        fk = close_sizes[idx] if idx < len(close_sizes) else 5
        mask = _foreground_from_smoothed_gray(gv, close_kernel=fk)
        tensors.append(_binary_mask_to_tensor(mask))

    # Adaptive threshold fallback on bilateral-smoothed L (helps uneven lighting inside glyph).
    smooth = cv2.bilateralFilter(lum, 9, 90, 90)
    bw = cv2.adaptiveThreshold(
        smooth,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV,
        31,
        5,
    )
    bw_alt = cv2.adaptiveThreshold(
        smooth,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,
        5,
    )
    if np.count_nonzero(bw) <= np.count_nonzero(bw_alt):
        adaptive_mask = bw
    else:
        adaptive_mask = bw_alt
    adaptive_mask = cv2.morphologyEx(adaptive_mask, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8), iterations=1)
    # Ensure strokes are the minority bright region (single character on background).
    fg_frac = float(np.count_nonzero(adaptive_mask > 127)) / adaptive_mask.size
    if fg_frac > 0.55:
        adaptive_mask = 255 - adaptive_mask
    tensors.append(_binary_mask_to_tensor(adaptive_mask))

    return np.concatenate([t for t in tensors if t.size > 0], axis=0)


def preprocess_for_inference(pil_image: Image.Image, *, source: str = "draw") -> np.ndarray:
    """Single (1,28,28,1) tensor — first variant only; prefer inference_input_batch for uploads."""
    batch = inference_input_batch(pil_image, source=source)
    return batch[0:1]
