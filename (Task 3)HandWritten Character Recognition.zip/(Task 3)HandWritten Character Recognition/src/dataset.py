from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
from extra_keras_datasets import emnist
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
import tensorflow_datasets as tfds
from tensorflow.keras.datasets import mnist


@dataclass(frozen=True)
class DatasetBundle:
    x_train: np.ndarray
    y_train: np.ndarray
    x_test: np.ndarray
    y_test: np.ndarray
    class_map: Dict[int, str]


def _normalize_images(images: np.ndarray) -> np.ndarray:
    images = images.astype("float32") / 255.0
    return np.expand_dims(images, axis=-1)


def _mnist_to_uppercase_map() -> Dict[int, str]:
    mapping = {}
    for idx in range(10):
        mapping[idx] = str(idx)
    for idx, ch in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ", start=10):
        mapping[idx] = ch
    return mapping


def _fix_emnist_orientation(images: np.ndarray) -> np.ndarray:
    # EMNIST orientation fix: rotate and flip to match MNIST orientation.
    images = np.transpose(images, (0, 2, 1))
    images = np.flip(images, axis=2)
    return images


def _prepare_emnist_letters(images: np.ndarray, labels: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    # Depending on loader variant, labels can be [0..25] or [1..26].
    labels = labels.astype(np.int32)
    if labels.min() == 1:
        labels = labels - 1
    labels = labels + 10
    images = _fix_emnist_orientation(images)
    return images, labels


def _load_emnist_tfds_letters() -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    # try_gcs=True prefers hosted TFDS artifacts over blocked upstream mirrors.
    train_ds = tfds.load("emnist/letters", split="train", batch_size=-1, try_gcs=True)
    test_ds = tfds.load("emnist/letters", split="test", batch_size=-1, try_gcs=True)
    train = tfds.as_numpy(train_ds)
    test = tfds.as_numpy(test_ds)

    x_train = train["image"].astype(np.uint8).squeeze(-1)
    y_train = train["label"].astype(np.int32)
    x_test = test["image"].astype(np.uint8).squeeze(-1)
    y_test = test["label"].astype(np.int32)
    x_train = _fix_emnist_orientation(x_train)
    x_test = _fix_emnist_orientation(x_test)
    # tfds labels are usually [0..25] already.
    return x_train, y_train, x_test, y_test


def _load_emnist_extra_keras_letters() -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    (x_train, y_train), (x_test, y_test) = emnist.load_data(type="letters")
    x_train, y_train = _prepare_emnist_letters(x_train, y_train)
    x_test, y_test = _prepare_emnist_letters(x_test, y_test)
    return x_train, y_train, x_test, y_test


def _load_emnist_openml_letters() -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    # OpenML id for EMNIST Letters dataset.
    X, y = fetch_openml(data_id=41082, return_X_y=True, as_frame=False)
    X = X.astype(np.uint8).reshape(-1, 28, 28)
    y = y.astype(np.int32)
    X, y = _prepare_emnist_letters(X, y)

    x_train, x_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.125,
        random_state=42,
        stratify=y,
    )
    return x_train, y_train, x_test, y_test


def load_digits_and_letters_dataset() -> DatasetBundle:
    (x_train_mnist, y_train_mnist), (x_test_mnist, y_test_mnist) = mnist.load_data()
    try:
        x_train_emnist, y_train_emnist, x_test_emnist, y_test_emnist = _load_emnist_tfds_letters()
        if y_train_emnist.min() == 1:
            y_train_emnist = y_train_emnist - 1
            y_test_emnist = y_test_emnist - 1
        y_train_emnist = y_train_emnist + 10
        y_test_emnist = y_test_emnist + 10
    except Exception:
        try:
            x_train_emnist, y_train_emnist, x_test_emnist, y_test_emnist = _load_emnist_extra_keras_letters()
        except Exception:
            try:
                x_train_emnist, y_train_emnist, x_test_emnist, y_test_emnist = _load_emnist_openml_letters()
            except Exception:
                # Fallback keeps the project runnable when EMNIST mirrors are blocked.
                x_train, y_train = x_train_mnist, y_train_mnist
                x_test, y_test = x_test_mnist, y_test_mnist
                class_map = {idx: str(idx) for idx in range(10)}
                x_train = _normalize_images(x_train)
                x_test = _normalize_images(x_test)
                return DatasetBundle(
                    x_train=x_train,
                    y_train=y_train,
                    x_test=x_test,
                    y_test=y_test,
                    class_map=class_map,
                )

        x_train = np.concatenate([x_train_mnist, x_train_emnist], axis=0)
        y_train = np.concatenate([y_train_mnist, y_train_emnist], axis=0)
        x_test = np.concatenate([x_test_mnist, x_test_emnist], axis=0)
        y_test = np.concatenate([y_test_mnist, y_test_emnist], axis=0)
        class_map = _mnist_to_uppercase_map()
    else:
        x_train = np.concatenate([x_train_mnist, x_train_emnist], axis=0)
        y_train = np.concatenate([y_train_mnist, y_train_emnist], axis=0)
        x_test = np.concatenate([x_test_mnist, x_test_emnist], axis=0)
        y_test = np.concatenate([y_test_mnist, y_test_emnist], axis=0)
        class_map = _mnist_to_uppercase_map()

    x_train = _normalize_images(x_train)
    x_test = _normalize_images(x_test)

    return DatasetBundle(
        x_train=x_train,
        y_train=y_train,
        x_test=x_test,
        y_test=y_test,
        class_map=class_map,
    )
