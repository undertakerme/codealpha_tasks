from __future__ import annotations

import argparse
import json
from pathlib import Path

from sklearn.model_selection import train_test_split
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

from src.dataset import load_digits_and_letters_dataset
from src.model import build_cnn_model


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train handwritten character recognition CNN.")
    parser.add_argument("--epochs", type=int, default=12, help="Training epochs.")
    parser.add_argument("--batch-size", type=int, default=128, help="Batch size.")
    parser.add_argument("--model-out", type=str, default="artifacts/handwritten_cnn.keras", help="Output model path.")
    parser.add_argument("--labels-out", type=str, default="artifacts/class_map.json", help="Output class mapping path.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    bundle = load_digits_and_letters_dataset()
    model = build_cnn_model(num_classes=len(bundle.class_map))

    x_train, x_val, y_train, y_val = train_test_split(
        bundle.x_train,
        bundle.y_train,
        test_size=0.1,
        random_state=42,
        stratify=bundle.y_train,
    )

    callbacks = [
        EarlyStopping(monitor="val_accuracy", patience=3, restore_best_weights=True),
        ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=2),
    ]

    model.fit(
        x_train,
        y_train,
        validation_data=(x_val, y_val),
        epochs=args.epochs,
        batch_size=args.batch_size,
        callbacks=callbacks,
        verbose=1,
    )

    test_loss, test_acc = model.evaluate(bundle.x_test, bundle.y_test, verbose=0)
    print(f"Test Accuracy: {test_acc:.4f} | Test Loss: {test_loss:.4f}")

    model_out = Path(args.model_out)
    labels_out = Path(args.labels_out)
    model_out.parent.mkdir(parents=True, exist_ok=True)
    labels_out.parent.mkdir(parents=True, exist_ok=True)

    model.save(model_out)
    with labels_out.open("w", encoding="utf-8") as fp:
        json.dump(bundle.class_map, fp, indent=2)

    print(f"Saved model to: {model_out}")
    print(f"Saved class map to: {labels_out}")


if __name__ == "__main__":
    main()
