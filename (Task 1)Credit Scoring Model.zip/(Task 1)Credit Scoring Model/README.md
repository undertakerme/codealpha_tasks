# Credit Scoring Model

End-to-end machine learning project to predict individual creditworthiness using historical-style financial features.

## Objective
- Predict whether an applicant is creditworthy (`1`) or not (`0`).
- Use classification algorithms: Logistic Regression, Decision Tree, and Random Forest.
- Evaluate using Precision, Recall, F1-Score, and ROC-AUC.

## Project Structure
- `src/data_generation.py`: creates a synthetic credit dataset.
- `src/train.py`: trains multiple models, selects best by F1, saves model and reports.
- `src/predict.py`: predicts on a single applicant using the saved model.
- `app.py`: Streamlit web app for interactive reviewer demo.
- `data/`: generated dataset (`credit_data.csv`).
- `models/`: persisted best model (`best_credit_model.joblib`).
- `reports/`: metrics and plots (ROC curve and confusion matrix).

## Features Used
- `age`
- `annual_income`
- `debt`
- `credit_history_years`
- `missed_payments`
- `loan_amount`
- `employment_years`

## Setup
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Run Pipeline
1. Generate dataset:
```bash
python src/data_generation.py
```

2. Train and evaluate:
```bash
python src/train.py
```

This creates:
- `models/best_credit_model.joblib`
- `reports/model_metrics.txt`
- `reports/roc_curve.png`
- `reports/confusion_matrix.png`

3. Predict a new applicant:
```bash
python src/predict.py --age 35 --annual_income 900000 --debt 150000 --credit_history_years 10 --missed_payments 1 --loan_amount 300000 --employment_years 8
```

4. Launch interactive web demo:
```bash
streamlit run app.py
```

This opens a browser UI where reviewers can change applicant profile inputs and get live prediction output.

## Notes
- The dataset is synthetic but generated with realistic relationships (income/debt/payment behavior).
- Best model is selected by F1-score on a stratified test split.
