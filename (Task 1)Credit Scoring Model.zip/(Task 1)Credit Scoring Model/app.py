import subprocess
import sys

import joblib
import pandas as pd
import streamlit as st

from src.config import MODEL_PATH


st.set_page_config(page_title="Credit Scoring Demo", page_icon="💳", layout="wide")
st.title("💳 Credit Scoring Model Demo")
st.caption("Interactive reviewer demo for creditworthiness prediction")

with st.expander("How to use this demo", expanded=True):
    st.markdown(
        """
1. Click **Train/Refresh Model** to generate data and train latest model.
2. Adjust applicant profile values in the sidebar.
3. Click **Predict Creditworthiness**.
4. Review class label and probability in the result cards.
"""
    )


def train_model_pipeline() -> tuple[bool, str]:
    try:
        data_proc = subprocess.run(
            [sys.executable, "src/data_generation.py"],
            check=True,
            capture_output=True,
            text=True,
        )
        train_proc = subprocess.run(
            [sys.executable, "src/train.py"],
            check=True,
            capture_output=True,
            text=True,
        )
        output = "\n".join([data_proc.stdout.strip(), train_proc.stdout.strip()]).strip()
        return True, output
    except subprocess.CalledProcessError as exc:
        details = (exc.stdout or "") + ("\n" + exc.stderr if exc.stderr else "")
        return False, details.strip() or str(exc)


@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


model = None

st.subheader("Model Controls")
train_clicked = st.button("Train/Refresh Model")
if train_clicked:
    with st.spinner("Training model... this may take a few seconds."):
        ok, logs = train_model_pipeline()
    if ok:
        load_model.clear()
        model = load_model()
        st.success("Model trained successfully.")
        if logs:
            st.text_area("Training Logs", value=logs, height=180)
    else:
        st.error("Training failed. Check logs below.")
        if logs:
            st.text_area("Training Error Logs", value=logs, height=180)

if not MODEL_PATH.exists():
    st.warning("Model not found yet. Click **Train/Refresh Model** to create it.")
    st.stop()

if model is None:
    model = load_model()

st.sidebar.header("Applicant Financial Profile")
age = st.sidebar.slider("Age", min_value=18, max_value=70, value=35)
annual_income = st.sidebar.number_input(
    "Annual Income", min_value=50000, max_value=5000000, value=900000, step=10000
)
debt = st.sidebar.number_input(
    "Existing Debt", min_value=0, max_value=3000000, value=150000, step=10000
)
credit_history_years = st.sidebar.slider(
    "Credit History (Years)", min_value=0, max_value=45, value=10
)
missed_payments = st.sidebar.slider("Missed Payments", min_value=0, max_value=20, value=1)
loan_amount = st.sidebar.number_input(
    "Requested Loan Amount", min_value=10000, max_value=3000000, value=300000, step=10000
)
employment_years = st.sidebar.slider("Employment Years", min_value=0, max_value=40, value=8)

input_df = pd.DataFrame(
    [
        {
            "age": age,
            "annual_income": float(annual_income),
            "debt": float(debt),
            "credit_history_years": float(credit_history_years),
            "missed_payments": int(missed_payments),
            "loan_amount": float(loan_amount),
            "employment_years": float(employment_years),
        }
    ]
)

st.subheader("Current Applicant Input")
st.dataframe(input_df, use_container_width=True)

if st.button("Predict Creditworthiness", type="primary"):
    probability = float(model.predict_proba(input_df)[0, 1])
    predicted_class = int(probability >= 0.5)
    label = "Creditworthy" if predicted_class == 1 else "Not creditworthy"

    col1, col2 = st.columns(2)
    col1.metric("Predicted Class", f"{predicted_class} ({label})")
    col2.metric("Creditworthy Probability", f"{probability:.2%}")

    if probability >= 0.75:
        st.success("Low-risk profile based on current model output.")
    elif probability >= 0.5:
        st.warning("Borderline profile. Additional checks may be required.")
    else:
        st.error("Higher-risk profile based on current model output.")
