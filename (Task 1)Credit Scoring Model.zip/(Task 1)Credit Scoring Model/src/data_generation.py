import numpy as np
import pandas as pd

from config import RAW_DATA_PATH


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def generate_credit_data(n_samples: int = 3000, random_state: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(random_state)

    age = rng.integers(21, 66, size=n_samples)
    annual_income = np.clip(rng.normal(750000, 300000, size=n_samples), 120000, 2500000)
    debt = np.clip(rng.normal(280000, 160000, size=n_samples), 0, 1200000)
    credit_history_years = np.clip(age - 18 - rng.integers(0, 12, size=n_samples), 1, 40)
    missed_payments = rng.poisson(1.2, size=n_samples)
    loan_amount = np.clip(rng.normal(400000, 220000, size=n_samples), 50000, 1500000)
    employment_years = np.clip(rng.normal(6.5, 4.5, size=n_samples), 0, 35)

    dti = debt / np.maximum(annual_income, 1)
    loan_income_ratio = loan_amount / np.maximum(annual_income, 1)

    score = (
        1.8
        + 0.0000022 * annual_income
        - 2.1 * dti
        - 0.85 * loan_income_ratio
        + 0.10 * credit_history_years
        - 0.48 * missed_payments
        + 0.04 * employment_years
    )
    prob_creditworthy = sigmoid(score)
    creditworthy = (rng.random(n_samples) < prob_creditworthy).astype(int)

    data = pd.DataFrame(
        {
            "age": age,
            "annual_income": annual_income.round(0).astype(int),
            "debt": debt.round(0).astype(int),
            "credit_history_years": credit_history_years.round(0).astype(int),
            "missed_payments": missed_payments.astype(int),
            "loan_amount": loan_amount.round(0).astype(int),
            "employment_years": employment_years.round(1),
            "creditworthy": creditworthy.astype(int),
        }
    )
    return data


def main() -> None:
    RAW_DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    df = generate_credit_data()
    df.to_csv(RAW_DATA_PATH, index=False)
    print(f"Generated dataset: {RAW_DATA_PATH}")
    print(df.head(5).to_string(index=False))


if __name__ == "__main__":
    main()
