import argparse

import joblib
import pandas as pd

from config import MODEL_PATH


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Predict creditworthiness for one applicant.")
    parser.add_argument("--age", type=int, required=True)
    parser.add_argument("--annual_income", type=float, required=True)
    parser.add_argument("--debt", type=float, required=True)
    parser.add_argument("--credit_history_years", type=float, required=True)
    parser.add_argument("--missed_payments", type=int, required=True)
    parser.add_argument("--loan_amount", type=float, required=True)
    parser.add_argument("--employment_years", type=float, required=True)
    return parser


def main() -> None:
    args = build_parser().parse_args()

    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Run `python src/train.py` first.")

    model = joblib.load(MODEL_PATH)

    input_df = pd.DataFrame(
        [
            {
                "age": args.age,
                "annual_income": args.annual_income,
                "debt": args.debt,
                "credit_history_years": args.credit_history_years,
                "missed_payments": args.missed_payments,
                "loan_amount": args.loan_amount,
                "employment_years": args.employment_years,
            }
        ]
    )

    prob = model.predict_proba(input_df)[0, 1]
    pred = int(prob >= 0.5)
    label = "Creditworthy" if pred == 1 else "Not creditworthy"

    print(f"Predicted class: {pred} ({label})")
    print(f"Creditworthy probability: {prob:.4f}")


if __name__ == "__main__":
    main()
