from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = PROJECT_ROOT / "models"
REPORTS_DIR = PROJECT_ROOT / "reports"

RAW_DATA_PATH = DATA_DIR / "credit_data.csv"
MODEL_PATH = MODELS_DIR / "best_credit_model.joblib"
METRICS_PATH = REPORTS_DIR / "model_metrics.txt"
ROC_PLOT_PATH = REPORTS_DIR / "roc_curve.png"
CONFUSION_PLOT_PATH = REPORTS_DIR / "confusion_matrix.png"
