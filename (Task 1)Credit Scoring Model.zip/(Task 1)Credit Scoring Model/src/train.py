import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

from config import (
    CONFUSION_PLOT_PATH,
    METRICS_PATH,
    MODEL_PATH,
    RAW_DATA_PATH,
    ROC_PLOT_PATH,
)


def load_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Run `python src/data_generation.py` first."
        )
    return pd.read_csv(path)


def build_models() -> dict:
    return {
        "logistic_regression": LogisticRegression(max_iter=2000, random_state=42),
        "decision_tree": DecisionTreeClassifier(max_depth=6, random_state=42),
        "random_forest": RandomForestClassifier(
            n_estimators=300, max_depth=8, min_samples_leaf=4, random_state=42
        ),
    }


def evaluate_model(model_name: str, pipeline: Pipeline, x_test: pd.DataFrame, y_test: pd.Series) -> dict:
    y_pred = pipeline.predict(x_test)
    y_proba = pipeline.predict_proba(x_test)[:, 1]

    return {
        "model": model_name,
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1_score": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_proba),
        "classification_report": classification_report(y_test, y_pred),
        "confusion_matrix": confusion_matrix(y_test, y_pred),
        "y_proba": y_proba,
    }


def save_plots(y_test: pd.Series, best_eval: dict) -> None:
    ROC_PLOT_PATH.parent.mkdir(parents=True, exist_ok=True)

    fpr, tpr, _ = roc_curve(y_test, best_eval["y_proba"])
    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, label=f"AUC = {best_eval['roc_auc']:.3f}")
    plt.plot([0, 1], [0, 1], linestyle="--")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title(f"ROC Curve ({best_eval['model']})")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(ROC_PLOT_PATH)
    plt.close()

    disp = ConfusionMatrixDisplay(best_eval["confusion_matrix"])
    disp.plot(values_format="d")
    plt.title(f"Confusion Matrix ({best_eval['model']})")
    plt.tight_layout()
    plt.savefig(CONFUSION_PLOT_PATH)
    plt.close()


def write_metrics(all_scores: list, best_eval: dict) -> None:
    lines = ["Credit Scoring Model Evaluation", "=" * 35, ""]
    lines.append("All model scores:")
    for row in all_scores:
        lines.append(
            f"- {row['model']}: Precision={row['precision']:.3f}, "
            f"Recall={row['recall']:.3f}, F1={row['f1_score']:.3f}, AUC={row['roc_auc']:.3f}"
        )

    lines.extend(
        [
            "",
            f"Best model: {best_eval['model']}",
            "",
            "Classification report:",
            best_eval["classification_report"],
        ]
    )

    METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)
    METRICS_PATH.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    df = load_data(RAW_DATA_PATH)

    x = df.drop(columns=["creditworthy"])
    y = df["creditworthy"]

    numeric_features = list(x.columns)
    preprocessor = ColumnTransformer(
        transformers=[("num", StandardScaler(), numeric_features)],
        remainder="drop",
    )

    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.2, random_state=42, stratify=y
    )

    model_defs = build_models()
    all_scores = []
    fitted_pipelines = {}

    for model_name, model in model_defs.items():
        pipeline = Pipeline(
            steps=[
                ("preprocessor", preprocessor),
                ("model", model),
            ]
        )
        pipeline.fit(x_train, y_train)
        scores = evaluate_model(model_name, pipeline, x_test, y_test)
        all_scores.append({k: v for k, v in scores.items() if k not in {"classification_report", "confusion_matrix", "y_proba"}})
        fitted_pipelines[model_name] = (pipeline, scores)

    best_row = max(all_scores, key=lambda row: row["f1_score"])
    best_model_name = best_row["model"]
    best_pipeline, best_eval = fitted_pipelines[best_model_name]

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(best_pipeline, MODEL_PATH)

    write_metrics(all_scores, best_eval)
    save_plots(y_test, best_eval)

    print("Training completed.")
    print(f"Best model saved to: {MODEL_PATH}")
    print(f"Metrics report: {METRICS_PATH}")
    print(f"ROC curve: {ROC_PLOT_PATH}")
    print(f"Confusion matrix: {CONFUSION_PLOT_PATH}")
    print("Scores:")
    print(json.dumps(all_scores, indent=2))


if __name__ == "__main__":
    main()
