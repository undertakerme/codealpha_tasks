# Credit Scoring Model - Complete Project Documentation

## 1) Project Overview

This project predicts whether an applicant is **creditworthy** (`1`) or **not creditworthy** (`0`) using historical-style financial inputs.

The implementation is complete end-to-end:

- Data generation
- Model training with multiple algorithms
- Model evaluation with business-relevant metrics
- Model persistence for reuse
- Command-line prediction
- Interactive web demo via Streamlit

---

## 2) Problem Statement

Financial institutions need fast and consistent credit-risk screening.  
This project simulates that process by taking applicant profile data and estimating the probability that the applicant is creditworthy.

### Objective
- Build a classification pipeline for creditworthiness prediction.
- Compare multiple models.
- Select the best model based on performance.
- Enable easy demonstration and interaction for reviewers.

---

## 3) Tech Stack

- **Language:** Python
- **Core libraries:** `pandas`, `numpy`, `scikit-learn`
- **Visualization:** `matplotlib`, `seaborn`
- **Model serialization:** `joblib`
- **Frontend/demo:** `streamlit`

---

## 4) Project Structure

```
Credit Scoring Model/
├── app.py
├── README.md
├── PROJECT_DOCUMENTATION.md
├── requirements.txt
├── .gitignore
├── data/
│   └── credit_data.csv
├── models/
│   └── best_credit_model.joblib
├── reports/
│   ├── model_metrics.txt
│   ├── roc_curve.png
│   └── confusion_matrix.png
└── src/
    ├── config.py
    ├── data_generation.py
    ├── train.py
    └── predict.py
```

### File Responsibilities

- `src/config.py`  
  Centralized paths for data, model, and report artifacts.

- `src/data_generation.py`  
  Builds a realistic synthetic dataset with relationships between income, debt, missed payments, employment years, and creditworthiness.

- `src/train.py`  
  Trains Logistic Regression, Decision Tree, and Random Forest; evaluates precision/recall/F1/ROC-AUC; saves best model and plots.

- `src/predict.py`  
  Accepts one applicant profile via CLI flags and outputs predicted class + probability.

- `app.py`  
  Interactive Streamlit UI for reviewers. Includes one-click training and live prediction.

---

## 5) Dataset and Features

The dataset is synthetic but intentionally generated with realistic risk patterns.

### Input Features
- `age`
- `annual_income`
- `debt`
- `credit_history_years`
- `missed_payments`
- `loan_amount`
- `employment_years`

### Target
- `creditworthy`  
  - `1`: likely creditworthy  
  - `0`: likely not creditworthy

### Generation Logic (High Level)

- Higher income and longer employment/credit history generally increase score.
- Higher debt, loan burden, and missed payments reduce score.
- A sigmoid transformation converts score into probability.
- Final class label is sampled from that probability.

This creates non-trivial patterns for model learning while remaining reproducible.

---

## 6) Model Development Pipeline

## Step 1: Data Load and Split
- Load CSV from `data/credit_data.csv`
- Split into train/test with stratification to preserve class distribution

## Step 2: Preprocessing
- Numeric features are scaled with `StandardScaler` via `ColumnTransformer`

## Step 3: Candidate Models
- Logistic Regression
- Decision Tree Classifier
- Random Forest Classifier

## Step 4: Evaluation
For each model, compute:
- Precision
- Recall
- F1-Score
- ROC-AUC
- Classification report
- Confusion matrix

## Step 5: Best Model Selection
- Best model is selected by **highest F1-score**.

## Step 6: Artifact Saving
- Save best model to `models/best_credit_model.joblib`
- Save text metrics to `reports/model_metrics.txt`
- Save ROC curve to `reports/roc_curve.png`
- Save confusion matrix to `reports/confusion_matrix.png`

---

## 7) Why These Metrics Matter

- **Precision:** Of predicted creditworthy applicants, how many were truly creditworthy.
- **Recall:** Of actual creditworthy applicants, how many were captured.
- **F1-Score:** Balanced score between precision and recall (good for decision balance).
- **ROC-AUC:** Threshold-independent separability measure.

In credit scenarios, balancing false approvals and false rejections is important, so using multiple metrics is better than relying on raw accuracy alone.

---

## 8) How to Run the Project

## A) Environment Setup

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## B) Run via CLI

1. Generate data:
```bash
python src/data_generation.py
```

2. Train and evaluate:
```bash
python src/train.py
```

3. Predict one applicant:
```bash
python src/predict.py --age 35 --annual_income 900000 --debt 150000 --credit_history_years 10 --missed_payments 1 --loan_amount 300000 --employment_years 8
```

## C) Run via Web UI

```bash
python -m streamlit run app.py
```

Then open `http://localhost:8501`.

---

## 9) Streamlit App Walkthrough

The web app supports:

- One-click **Train/Refresh Model** button
  - Runs data generation and training inside app
  - Displays training logs
- Sidebar controls for applicant profile
- Live prediction output:
  - Class label (`Creditworthy` / `Not creditworthy`)
  - Probability score
  - Risk message (low/borderline/high)

This makes the project review-friendly even without a traditional production frontend.

---

## 10) Reviewer Demo Script (Suggested)

Use this flow for presentation:

1. Explain objective in 20-30 seconds.
2. Show `reports/model_metrics.txt` and model comparison.
3. Open ROC and confusion matrix plots.
4. Launch Streamlit and click **Train/Refresh Model**.
5. Enter a low-risk profile and predict.
6. Enter a high-risk profile and predict.
7. Explain why probability shifts (debt, missed payments, loan ratio effects).

This demonstrates both technical quality and practical usability.

---

## 11) Current Artifacts Produced

After successful run, these are generated automatically:

- `data/credit_data.csv`
- `models/best_credit_model.joblib`
- `reports/model_metrics.txt`
- `reports/roc_curve.png`
- `reports/confusion_matrix.png`

---

## 12) Error Handling and Troubleshooting

### Model not found in app
- Click **Train/Refresh Model** in the UI, or run:
  - `python src/data_generation.py`
  - `python src/train.py`

### `streamlit` command not found
- Use:
  - `python -m streamlit run app.py`

### Dependency issues
- Reinstall:
```bash
pip install -r requirements.txt
```

---

## 13) Design Decisions

- **Synthetic data** was chosen to keep the project runnable without private banking data.
- **Multiple models** were used to show comparative analysis and model selection.
- **F1-based selection** balances precision and recall for practical credit screening.
- **Saved model artifacts** make inference reusable and deployment-friendly.
- **Streamlit integration** improves reviewer interaction without complex frontend engineering.

---

## 14) Limitations

- Data is synthetic, not institution-specific real-world data.
- No fairness/bias audit currently included.
- No threshold optimization by business cost matrix yet.
- No API deployment layer (Flask/FastAPI) yet.

---

## 15) Future Enhancements

- Hyperparameter tuning with `GridSearchCV` / `RandomizedSearchCV`
- Feature importance and SHAP explainability
- Threshold tuning based on rejection/approval cost
- Bias/fairness metrics across applicant groups
- REST API wrapper for production integration
- Containerization with Docker

---

## 16) Final Summary

This is a complete ML classification project for credit scoring:

- Reproducible pipeline
- Multi-model training and comparison
- Proper metric-based evaluation
- Saved artifacts and inference
- Interactive demo for reviewer presentation

It is suitable for academic showcase, internship portfolio, and entry-level production-style demonstration.

